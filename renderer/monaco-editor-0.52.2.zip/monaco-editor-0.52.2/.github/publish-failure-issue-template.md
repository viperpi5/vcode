---
title: NPM Publishing Failed
assignees: []
labels: bug
---

NPM publishing failed. Check the last GitHub Action log.
